#ifndef _ROUTPLANNING_H
#define _ROUTPLANNING_H

void routplanning(double armbaselong,double arm2rate,double arm3rate,double angle1,double angle2,double angle3,double angle4,double distance,int pointsnum);

#endif

