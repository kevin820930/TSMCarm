#ifndef _mylagrange_H
#define _mylagrange_H

void lagrange(long double indata[][2],int time);
void calculate(long double indata[][2],int count,int havechoice[100],long double anser[100][100],int choicenum);

#endif


