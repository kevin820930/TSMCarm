#include <stdio.h>
#include <stdlib.h>
#include "scheduleing.h"
#include "initialize.h"
#include "routplanning.h"
#include "generator.h"

#define armbaselong 320
#define arm2rate 0.53125
#define arm3rate 0.9375

//need modify
#define tmp1 28.1748
#define tmp2 89.1047
#define tmp3 62.72038
#define distance 130
//need modify

#define pointsnum 10

int main(){

    int coordinate[10][3];
    int scheduleing[100][2];
    anglelist *go[10];
    /*
    Double digits.first digit is the task cassetteA:0,A:1,B:2,C:3,cassetteB:4
    Second digit is the chamber number of task
    */


    printf("-------game start-------\n");

    //initialize coordinate
    Initialize(coordinate);    

    //scheduleing
    ScheduleFunction(scheduleing);
    

    //roudplaining
    int i=0;
    for(i=0;i<10;i++){
        go[i]=(anglelist *)malloc(sizeof(anglelist));
    }
    anglelist *tmp=(anglelist *)malloc(sizeof(anglelist));
    *go[0]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[0][1]+tmp1,coordinate[0][2],tmp2,170-tmp3,distance,pointsnum);
    *go[1]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[1][1]+tmp1,coordinate[1][2],tmp2,170-tmp3,distance,pointsnum);
    *go[2]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[2][1]+tmp1,coordinate[2][2],tmp2,170-tmp3,distance,pointsnum);
    *go[3]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[3][1]+tmp1,coordinate[3][2],tmp2,170-tmp3,distance,pointsnum);
    *go[4]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[4][1]+tmp1,coordinate[4][2],tmp2,170-tmp3,distance,pointsnum);
    *go[5]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[5][1]+tmp1,coordinate[5][2],tmp2,170-tmp3,distance,pointsnum);
    *go[6]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[6][1]+tmp1,coordinate[6][2],tmp2,170-tmp3,distance,pointsnum);
    *go[7]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[7][1]+tmp1,coordinate[7][2],tmp2,170-tmp3,distance,pointsnum);
    *go[8]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[8][1]+tmp1,coordinate[8][2],tmp2,170-tmp3,distance,pointsnum);
    *go[9]=routplanning(armbaselong,arm2rate,arm3rate,coordinate[9][1]+tmp1,coordinate[9][2],tmp2,170-tmp3,distance,pointsnum);

    printf("fuck %LF %LF\n",go[0]->one,go[0]->nextangle->one);
   
    //end plaining 

    //Nccode generator
    generator(go,scheduleing);    

    //end generate
    printf("-------game over,good luck-------\n");

}
