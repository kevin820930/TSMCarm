void ScheduleFunction(int scheduleing[100][2]);
