#include "routplanning.h"

void generator(anglelist *go[8],int scheduleing[100][2]);
