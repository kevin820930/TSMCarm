#include<stdio.h>
#include"initialize.h"

void Initialize(int coordinate[10][3]){

/*
the first layer(highter one) are 0~3(left to right);second layer(lower one) are 4~7(left to right)
*/
    int i;
    for(i=0;i<5;i++){
	coordinate[i][0]=760;//ridio
	coordinate[i][1]=(i+1)*30;//angle
	coordinate[i][2]=0;//z
	coordinate[i+5][0]=760;//ridio
        coordinate[i+5][1]=(i+1)*30;//angle
        coordinate[i+5][2]=0;//z
	//printf("coordinate %d:%d,%d,%d",i,coordinate[i][0],coordinate[i][1],coordinate[i][2]);
    }
}
