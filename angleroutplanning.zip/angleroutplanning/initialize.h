
void Initialize(int coordinate[10][3]);
